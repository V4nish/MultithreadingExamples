#include <thread>
#include <iostream>
#include <vector>
#include <chrono>
#include <random>
#define SIZE 10000000

//Przyspiesz wyszukiwanie dzieliac tablice na pol, kazda polowe innym watkiem, porownaj czasy wykonywania programu

int ile(int*tab,int count,int what)
{
	int counter=0;
	for (int i = 0; i < count; i++)
	{
		tab[i] == what ? counter++ : false;
	}
	return counter;
}

void ilethr(int*tab, int from, int to, int what,int&counter)
{
	for (int i = from; i < to; i++)
	{
		tab[i] == what ? counter++ : false;
	}
	return;
}

int main()
{
	srand(time(NULL));
	std::chrono::steady_clock sc;
	
	int counter = 0;
	int tab[SIZE];
	for (size_t i = 0; i < SIZE; i++)
	{
		tab[i] = rand() % 100;
	}

	auto start = sc.now();	// start timer
 	counter = ile(tab, SIZE, 10);
	auto end = sc.now();	// end timer

	std::cout << counter<<std::endl;
	
	auto time_span = static_cast<std::chrono::duration<double>>(end - start);
	std::cout << "Wyszukiwanie zajelo: " << time_span.count() << " sekund\n";

	//...

	system("pause");
	return 0;
}