#include <thread>
#include <iostream>
#include <string>
#include <conio.h>
#include <windows.h>

//Uzupelnj kod korzystajac z wielowatkowosci, aby zczytywanie z klawiatury odbywalo sie in real-time

void pobieraj(std::string& buffer)
{
	while (true)
	{
	//...
	}
}
int main()
{
	std::string buffer;
	//...
	while (true)
	{
		system("CLS");
		std::cout << buffer << std::endl;
		Sleep(50);
	}
}