#include <iostream>
#include <thread>
#include <mutex>
#include <Windows.h>
std::mutex m1,m2;

//A
//napisz 2 w�tki i uruchom je
//dla t1 uzyj funkcji print1(), a dla t2 print2()
//B
//Zakomentuj pp A
//wykonaj ponownia pp A, ale
//dla t1 uzyj funkcji print1()
//dla t2 napisz funkcje lambda o tym samym dzialaniu co print2()
//C
//zapewnij przylaczenie watkow do glowenego progamu przed jego zakonczeniem
//D
//zaloz mutexy, tak aby najpierw zostal wypisany 100 razy jan, a potem 100 razy pawel

void print1()
{
	//D
	for (int i = 0; i < 100; i++)
	{
		std::cout << "jan" <<  std::endl;
	}

}

void print2()
{
	//D
	for (int i = 0; i < 100; i++)
	{
		std::cout << "pawel" << std::endl;
	}

}
 
int main()
{
	//A


	//B


	//C


	system("pause");
	return 0;
}