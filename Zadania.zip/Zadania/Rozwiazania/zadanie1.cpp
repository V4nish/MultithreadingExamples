#include <iostream>
#include <thread>
#include <mutex>
#include <Windows.h>
std::mutex m1,m2;

//A
//napisz 2 w�tki i uruchom je
//dla t1 uzyj funkcji print1(), a dla t2 print2()
//B
//Zakomentuj pp A
//wykonaj ponownia pp A, ale
//dla t1 uzyj funkcji print1()
//dla t2 napisz funkcje lambda o tym samym dzialaniu co print2()
//C
//zapewnij przylaczenie watkow do glowenego progamu przed jego zakonczeniem
//D
//zaloz mutexy, tak aby najpierw zostal wypisany 100 razy jan, a potem 100 razy pawel

void print1()
{
	//D
	/*std::lock(m1, m2);*/
	for (int i = 0; i < 100; i++)
	{
		std::cout << "jan" <<  std::endl;
	}
	/*m1.unlock();
	m2.unlock();*/
}

void print2()
{
	//D
	/*std::lock(m2, m1);*/
	for (int i = 0; i < 100; i++)
	{
		std::cout << "pawel" << std::endl;
	}
	/*m2.unlock();
	m1.unlock();*/
}
 
int main()
{
	//A
	//std::thread t1(print1);
	//std::thread t2(print2);

	//B
	//std::thread t1(print1);
	//std::thread t2([] {for (int i = 0; i < 100; i++)std::cout << "pawel" << std::endl; });

	//C
	//t1.join();
	//t2.join();

	system("pause");
	return 0;
}