#include <thread>
#include <iostream>
#include <string>
#include <conio.h>
#include <windows.h>

//Uzupelnj kod korzystajac z wielowatkowosci, aby zczytywanie z klawiatury odbywalo sie in real-time

void pobieraj(std::string& buffer)
{
	while (true)
	{
		/*char x;
		x=_getch();
		buffer += x;*/
	}
}
int main()
{
	std::string buffer;
	//std::thread t1(pobieraj, std::ref(buffer));
	while (true)
	{
		system("CLS");
		std::cout << buffer << std::endl;
		Sleep(50);
	}
}