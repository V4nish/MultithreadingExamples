#include <iostream>       
#include <atomic>         
#include <thread>     
#include <vector>
//A
//Uzyj typu atomowego w strukturze licznik, aby wynik inkrementacji byl poprawny

//B
//Zastap funkcje lambda wskaznikiem fx na funkcje dodaj(licznik l)

//C
//Odlacz wszystkie watki i zaobserwuj wynik dzialania programu
class licznik {
public:
	//A
	int value;

	licznik() : value(0) {}

	int operator ++(int) 
	{
		++value;
		return this->value;
	}
};

void dodaj(licznik &l)
{
	for (int i = 0; i < 10000000; i++)
	{
		l++;
	}
	
}

int main() 
{

	licznik counter;
	std::vector<std::thread> threads;

	for (int i = 0; i < 5; ++i) 
	{
		threads.push_back(std::thread([&counter]() {for (int i = 0; i < 10000000; ++i) {counter++;}}));
		//C
	}
	

	//B

	for (int i = 0;i<5;i++) 
	{
		threads[i].join();
	}

	std::cout << counter.value << std::endl;
	system("pause");
	return 0;
}